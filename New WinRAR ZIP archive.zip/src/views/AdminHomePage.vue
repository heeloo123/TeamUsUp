<template>
    <h1> admin home page</h1>
</template>